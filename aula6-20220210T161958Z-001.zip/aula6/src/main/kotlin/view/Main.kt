package view
import model.Music
fun main() {
    val musicController = controller.Music()
    val music = musicController.musicFactory(
        duration = 120,
        title = "Protectors of the Earth",
        composer = "Two Steps From Hell",
        genre = "Progressive Metal",
        releaseYear = "2019",
        record = "Universal Musics"
    )
}