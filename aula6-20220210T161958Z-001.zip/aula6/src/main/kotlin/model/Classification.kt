package model

enum class Classification {
    MATURE,CHILDREN,TEENAGER
}