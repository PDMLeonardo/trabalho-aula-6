package model

class Music (
    var title:String,
    var duration:Short,
    var musicGenre:String,
    var releaseYear:Short,
    var album:String,
    var composer:String,
    var record:String,
)