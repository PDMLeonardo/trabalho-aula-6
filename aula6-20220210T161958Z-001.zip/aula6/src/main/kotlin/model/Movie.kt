package model

class Movie{
    var title:String,
    var genre: MovieGenre,
    var duration: Short,
    var classification: Classification,
    var premiere: Boolean,
    var releaseYear: Short,
    var movieDirector:String,
    var screenwriter: String,


    constructor(
        title: String,
        genre: MovieGenre,
        duration: Short,
        classification: Classification,
        premiere: Boolean,
        releaseYear: Short,
        movieDirector: String,
        screenwriter: String
    ) {
        this.title = title
        this.genre = genre
        this.duration = duration
        this.classification = classification
        this.premiere = premiere
        this.releaseYear = releaseYear
        this.movieDirector = movieDirector
        this.screenwriter = screenwriter
    }

    override fun toString(): String {
        return "Movie(title='$title', genre=$genre, duration=$duration, classification=$classification, premiere=$premiere, releaseYear=$releaseYear, movieDirector='$movieDirector', screenwriter='$screenwriter')"
    }
}
