package controller
import model.Music

data class Music{
     fun musicFactory(
        title:String,
        duration:Short,
        genre:String,
        releaseYear:Short,
        album:String,
        composer:String,
        record:String,
    ):Music = model.Music(
        title = title,
        duration = duration,
        musicGenre = genre,
        releaseYear = releaseYear,
        album = album,
        composer = composer,
        record = record,

    )

}