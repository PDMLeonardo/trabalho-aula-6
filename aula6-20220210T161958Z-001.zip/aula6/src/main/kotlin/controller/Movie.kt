package controller
import model.Classification
import model.Movie
import model.MovieGenre

class Movie {
    fun movieFactory(
        title:String,
        genre:MovieGenre,
        duration:Short,
        classification: Classification,
        premiere:Boolean,
        releaseYear:Short,
        movieDirector:String,
        screenwriter:String,
    ) = model.Movie(
        title = title,
        genre = genre,
        duration = duration,
        classification = classification,
        premiere = premiere,
        releaseYear = releaseYear,
        movieDirector = movieDirector,
        screenwriter = screenwriter,
    )
}